package com.example.Ofosu8249.connector;

import com.example.Ofosu8249.connector.DataContainer.Gooddetail;
import com.example.Ofosu8249.connector.DataContainer.collections;
import com.example.Ofosu8249.connector.DataContainer.vendorDetails;

import java.sql.SQLException;
import java.text.ParseException;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public class Controller {
    private Gooddetail stack_gooddetail;
    private Gooddetail queue_gooddetail;
    private Gooddetail list_gooddetail;
    private vendorDetails ven;

    collections db=new collections();

    public Stack<Gooddetail> getgood(){
        return db.getgood();

    }
public List<Gooddetail>getall(){
        return db.Productlist;
}

public List<Gooddetail>getlistg(){
        return db.getgood_list();
}
public Queue<Gooddetail>getqgood(){
        return  db.getQlist();

}public void searchcat(String g) throws Exception {
        db.connect();
        db.Load_data();
        db.searchresult(g);

    }
    public List<Gooddetail>getSgood(){
        return db.getSearchcat();
    }

public HashMap<String, vendorDetails> getvendor(){
        return db.Getvendors();
}


public void connect() throws Exception {

        db.connect();

}
public void save_with_stack() throws SQLException {
        db.stackGooddetail.clear();
        db.addgood(stack_gooddetail);
        db.save_To_database_stack();
}
    public void save_with_queue() throws SQLException {
        db.queueGooddetail.clear();
        db.addQueuegood(queue_gooddetail);
        db.save_To_database_queue();
    }
    public void save_with_list() throws SQLException {
        db.listgood.clear();
        db.add_good_to_list(list_gooddetail);
        db.save_To_database_list();
    }
public void load() throws SQLException {
        db.Load_data();


}


public void delectStack() throws Exception {
        db.connect();
        db.Load_data();
        db.removegood();
}

public void delectQueue() throws Exception{
       db.connect();
        db.Load_data();
        db.removegood_queue();
}
public void stackcount(){
      db.c_s();
}
    public void queuecount(){
db.q_s();
    }
    public void listcount(){
db.l_s();
    }
    public void itemcount(){
db.a_l();
    }
    public void delectList(int a) throws Exception{
        db.connect();
        db.Load_data();
        db.removegood_list(a);
    }
public HashMap<String, vendorDetails> getVendor(){
        return db.venderdetails;
}
    public void addgoodstack(String catn, String prodn, Date daten, int quatn, double purchn, double salena, double grosna, double grosSalen, String catsel, String productsel, String vendorn) throws ParseException {
      stack_gooddetail =new Gooddetail(catn,prodn,daten,quatn,purchn,salena,grosna,vendorn);

    }
    public void addgoodqueue(String catn, String prodn, Date daten, int quatn, double purchn, double salena, double grosna, double grosSalen, String catsel, String productsel, String vendorn) throws ParseException {
        queue_gooddetail = new Gooddetail(catn, prodn, daten, quatn, purchn, salena, grosna, vendorn);
    }
    public void addgoodlist(String catn, String prodn, Date daten, int quatn, double purchn, double salena, double grosna, double grosSalen, String catsel, String productsel, String vendorn) throws ParseException {
        list_gooddetail = new Gooddetail(catn, prodn, daten, quatn, purchn, salena, grosna, vendorn);
    }

}
