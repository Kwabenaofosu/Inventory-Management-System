package com.example.Ofosu8249.connector.DataContainer;

import java.sql.*;
import java.sql.Date;
import java.util.*;

public class collections {
    public Stack<Gooddetail> stackGooddetail;
    public Queue<Gooddetail> queueGooddetail;
    public List<Gooddetail>listgood;

    public HashMap<String, vendorDetails> venderdetails;
    public List<Gooddetail>Productlist;
    public List<Gooddetail>Searchfilter;
    public List<String>cat14;
    public List<String>cat57;
    public List<String>cat811;
    private int rand;
    public  Map<Integer, SalesDetails>sales;

    public String getDisplayType() {
        return displayType;
    }

    public void setDisplayType(String displayType) {
        this.displayType = displayType;
    }

    private String displayType;


    private Connection con;


    public collections(){

        stackGooddetail = new Stack<>();
        queueGooddetail = new LinkedList<>();
      venderdetails=new HashMap<>();
        listgood=new ArrayList<>();
        Productlist=new ArrayList<>();
        Searchfilter=new ArrayList<>();
        List<String>containss=new ArrayList<>();
        containss.add("Meat");
        containss.add("Produce");
        containss.add("Cleaners");
        containss.add("Paper Goods");
        containss.add("Personal Care");




sales=new HashMap<>();



cat14=new ArrayList<>();
cat57=new ArrayList<>();
cat811=new ArrayList<>();


cat14.add("Beverages");
cat14.add("Bread/Bakery");
cat14.add("Canned/Jarred Goods");
cat14.add("Dairy");

cat57.add("Dry/Baking Goods");
cat57.add("Frozen Foods");
cat57.add("Meat");
cat811.add("Produce");
cat811.add("Cleaners");
cat811.add("Paper Goods");
cat811.add("Personal Care");





    }
    /** queue****************************************************************************************/
    /** Add ap product to queue--------------------------------------------------------------------- */
    public  void addQueuegood(Gooddetail g)
    {

        queueGooddetail.add(g);
    }
    /** Remove from QUEUE********************************************************************************/
    public void removeQueue_good(){
        queueGooddetail.remove();

    }
    public Queue<Gooddetail> getQlist(){
        return queueGooddetail;
    }
    /** **********************QUEUE LINE ENDS*******************************************************************************************/




    /*** ********************STACK BEGINS******************************************************************************************/


    /** stack   ADD    */
    public void addgood(Gooddetail g){

        stackGooddetail.push(g);


    }

    /** *******************REMOVE FROM  STACK ***********************/
    public void removegood() throws SQLException {
         Gooddetail nw= stackGooddetail.pop();
        String deletestate="delete from good where id="+nw.getId();
        PreparedStatement stm=con.prepareStatement(deletestate);
        stm.executeUpdate();
        stm.close();



    }


    public void searchresult(String gg){
        Searchfilter.clear();
        for(Gooddetail g:Productlist){
            if(Objects.equals(gg, g.getCategory())){
                Searchfilter.add(g);

            }
            System.out.println(g.getCategory());
            System.out.println(Searchfilter.size());
        }
    }
    public List<Gooddetail> getSearchcat(){
        return Searchfilter;
    }

    public void removegood_list(int a) throws SQLException {
        Gooddetail nw=listgood.remove(a);
        String deletestate="delete from good where id="+nw.getId();
        PreparedStatement stm=con.prepareStatement(deletestate);
        stm.executeUpdate();
        stm.close();



    }
    public void removegood_queue() throws SQLException {
        Gooddetail nw= queueGooddetail.remove();
        String deletestate="delete from good where id="+nw.getId();
        PreparedStatement stm=con.prepareStatement(deletestate);
        stm.executeUpdate();
        stm.close();



    }
    public int c_s(){
        return stackGooddetail.size();
    }

    public int l_s(){
        return listgood.size();
    }
    public int q_s(){
        return queueGooddetail.size();
    }

    public int a_l(){
        return Productlist.size();
    }


    /*** GET GOOD FROM stack***********************************/


    public Stack<Gooddetail> getgood(){
        return stackGooddetail;
    }
/*****



 / **************LIST FOR ADD CATEGORY 8 TO 11 ****************************************/
/** add */
public void add_good_to_list(Gooddetail g){
    listgood.add(g);
}
/** remove */
public void remove_good_list(int a){
  listgood.remove(a);
}
public List<Gooddetail> getgood_list(){
    return listgood;
}

/**********END ************************************ **/


/********************** ADD******************/




/****************************        STORE VENDOR DETAILS USING HASHMAP***/
public void Addvendor(String name, vendorDetails detail){
    venderdetails.put(name,detail);
}

/****      sales record                   ******************     ***/
public  Map<Integer, SalesDetails> getSales(){
return sales;
}
public void storesale(int id, SalesDetails s){
    sales.put(id,s);
}
/*************  GET SALE RECORDS ******/

/********** Get vendors*********************/
public HashMap<String, vendorDetails> Getvendors(){
    return venderdetails;
}

public void removevendor(String n){
    venderdetails.remove(n);
}
/*************** end of hashmap****/





/********   DATABASE CONNECTION *******************************************/
    public void connect() throws Exception  {
        if(con !=null) return;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("driver connected");
        }
        catch( ClassNotFoundException  e){
        throw    new Exception("driver not found");


        }
String mysqlurl="jdbc:mysql://localhost:3306/NEWBEST";
        con= DriverManager.getConnection(mysqlurl,"root","Kuagbenu12345");

System.out.println("conected to "+con);


    }

    /*** DISCONNECT***************************/
    public void disconnected()  {
if(con !=null){
    try{
        con.close();
    }
    catch(SQLException e){
      System.out.println("not close");
    }

}
    }
/****************************sAVE VENDORS**********************************/
public void save_To_database_vendor() throws SQLException {


    String Doc="insert into vendors (name,address,firm,contact_number,country,city) values(?,?,?,?,?,?)";

    PreparedStatement insertDoc=con.prepareStatement(Doc);
    Iterator hash = venderdetails.entrySet().iterator();
for(HashMap.Entry<String, vendorDetails>e:venderdetails.entrySet()){
    String name=e.getKey().toString();
    String add=e.getValue().getAddress();
   int cont=e.getValue().getContact();
    String comp=e.getValue().getCompany();
    String count=e.getValue().getCountry();
    String town=e.getValue().getTown();
    int size=venderdetails.size()+1;
    insertDoc.setString(1,name);
    insertDoc.setString(2,add);

    insertDoc.setString(3,comp);
    insertDoc.setInt(4,cont);
    insertDoc.setString(5,count);
    insertDoc.setString(6,town);

    insertDoc.executeUpdate();
    System.out.print("vendor saved");

}
    stackGooddetail.clear();
    insertDoc.close();

}


    /********    adding to database  using *****************/
    public void save_To_database_stack() throws SQLException {

        int size=Productlist.size()+1;
        String Doc="insert into good(category,product,date,quantity,unit_price,sale_price,gross_price,vendorId) values(?,?,?,?,?,?,?,?)";

        PreparedStatement insertDoc=con.prepareStatement(Doc);

        for(Gooddetail g: stackGooddetail){

            int id=g.getId();


            String  cat=g.getCategory();
            String p=g.getGood();

           Date dat= (Date) g.getDate();
            int quan=g.getQuant();
            Double up=g.getUnit_price();
            Double sp=g.getSaleprice();
            Double gp=g.getGrossprice();

            String ven=g.getVendor();

                insertDoc.setString(1,cat);
                insertDoc.setString(2,p);
                insertDoc.setDate(3,dat);
                insertDoc.setInt(4,quan);
                insertDoc.setDouble(5,up);
                insertDoc.setDouble(6,sp);
                insertDoc.setDouble(7,gp);

                insertDoc.setString(8,ven);
                insertDoc.executeUpdate();
System.out.println("inserted");


        }
        Productlist.clear();

stackGooddetail.clear();
insertDoc.close();

    }


    /**************** queues *********************************************************************/

    public void save_To_database_queue() throws SQLException {


        String Doc="insert into good(category,product,date,quantity,unit_price,sale_price,gross_price,vendorId) values(?,?,?,?,?,?,?,?)";

        PreparedStatement insertDoc=con.prepareStatement(Doc);

        int size= Productlist.size()+1;
        for(Gooddetail g: queueGooddetail){




            String  cat=g.getCategory();
            String p=g.getGood();
            Date dat= (Date) g.getDate();
            int quan=g.getQuant();
            Double up=g.getUnit_price();
            Double sp=g.getSaleprice();
            Double gp=g.getGrossprice();

           String ven=g.getVendor();








                insertDoc.setString(1,cat);
                insertDoc.setString(2,p);
                insertDoc.setDate(3,dat);
                insertDoc.setInt(4,quan);
                insertDoc.setDouble(5,up);
                insertDoc.setDouble(6,sp);
                insertDoc.setDouble(7,gp);
                insertDoc.setString(8,ven);
                insertDoc.executeUpdate();


            }





        Productlist.clear();
       queueGooddetail.clear();
        insertDoc.close();

    }

/********           Storing product with list ************/
    public void save_To_database_list() throws SQLException {


        String Doc="insert into good(category,product,date,quantity,unit_price,sale_price,gross_price,vendorId) values(?,?,?,?,?,?,?,?)";
        int size=Productlist.size()+1;

        PreparedStatement insertDoc=con.prepareStatement(Doc);
        System.out.println("list head");
        for(Gooddetail g:listgood){
            System.out.println("dg"+Productlist.size());
            int id=g.getId();


            String  cat=g.getCategory();
            String p=g.getGood();

            Date dat= (Date) g.getDate();
            int quan=g.getQuant();
            Double up=g.getUnit_price();
            Double sp=g.getSaleprice();
            Double gp=g.getGrossprice();

            String ven=g.getVendor();






            System.out.println("list");

                insertDoc.setString(1,cat);

                insertDoc.setString(2,p);
                insertDoc.setDate(3,dat);
                insertDoc.setInt(4,quan);
                insertDoc.setDouble(5,up);
                insertDoc.setDouble(6,sp);
                insertDoc.setDouble(7,gp);

                insertDoc.setString(8,ven);
                insertDoc.executeUpdate();
            System.out.println("list");
            }





        Productlist.clear();
        listgood.clear();
        insertDoc.close();

    }

    /*******************************************************************************************/


    String gh="d";
    public void Load_data() throws SQLException {
        stackGooddetail.clear();
        Productlist.clear();
        queueGooddetail.clear();
        listgood.clear();
        String loader="select * from good";
        Statement state=con.createStatement();
        ResultSet result=state.executeQuery(loader);
        while(result.next()){
            int id=result.getInt("id");
            String cat=result.getString("category");
            String good=result.getString("product");
           Date date=result.getDate("date");
            int quan=result.getInt("quantity");
            Double unitprice=result.getDouble("unit_price");
            Double salep=result.getDouble("sale_price");
            Double grossp=result.getDouble("gross_price");

            String vendor=result.getString("vendorId");

            gh=cat;
        if(cat14.contains(cat)) {

              addgood(new Gooddetail(id,cat,good,date,quan,unitprice,salep,grossp,vendor));


            }
            if(cat57.contains(cat)){

               addQueuegood(new Gooddetail(id,cat,good,date,quan,unitprice,salep,grossp,vendor));


            }
            if(cat811.contains(cat)){

                add_good_to_list(new Gooddetail(id,cat,good,date,quan,unitprice,salep,grossp,vendor));

            }

            Productlist.add(new Gooddetail(id,cat,good,date,quan,unitprice,salep,grossp,vendor));



        }


        result.close();
        state.close();




    }
    public void Load_data_v() throws SQLException {
        venderdetails.clear();
        Getvendors().clear();
        String loader="select * from vendors";
        Statement state=con.createStatement();
        ResultSet result=state.executeQuery(loader);
        while(result.next()){
            int id=result.getInt("id");
            String name=result.getString("name");
            String address=result.getString("address");
            String company=result.getString("firm");
            int contact=result.getInt("contact_number");
            String country=result.getString("country");
            String city=result.getString("city");
            Addvendor(name,new vendorDetails(id,address,company,contact,country,city));







        }



        for(Map.Entry<String, vendorDetails>e:Getvendors().entrySet()){
            System.out.println("loaded to hash"+Getvendors().size());
        }
        result.close();
        state.close();





    }

    public void save_To_vsaleDate() throws SQLException {


        String Doc="insert into  sales (product ,category ,quantity ,u_price ,price,customer,prodid) values(?,?,?,?,?,?,?)";

        PreparedStatement insertDoc=con.prepareStatement(Doc);

        for(Map.Entry<Integer, SalesDetails>e:sales.entrySet()){
           int id=e.getKey();
            String cat=e.getValue().getCat();
            String prod=e.getValue().getProduct();
            String cus=e.getValue().getCus();
            int qty=e.getValue().getQty();
            double u_p=e.getValue().getPriceu();
           double total=e.getValue().getTotal();
            int size=sales.size()+1;
            insertDoc.setString(1,prod);
            insertDoc.setString(2,cat);

            insertDoc.setInt(3,qty);
            insertDoc.setDouble(4,u_p);
            insertDoc.setDouble(5,total);
            insertDoc.setString(6,cus);
            insertDoc.setInt(7,id);


           insertDoc.executeUpdate();


        }

        insertDoc.close();

    }


    public void update_vsaleD(int a,int b) throws SQLException {


        String Doc="update good set quantity='"+a+"' where id='"+b+"'";

        PreparedStatement insertDoc=con.prepareStatement(Doc);

        insertDoc.executeUpdate();

        insertDoc.close();


    }


    public void Load_data_SALE() throws SQLException {


        String loader="select * from sales";
        Statement state=con.createStatement();
        ResultSet result=state.executeQuery(loader);
        while(result.next()){
            int id=result.getInt("id");
            String product=result.getString("product");
            String category=result.getString("category");
            int quan=result.getInt("quantity");
            Double up=result.getDouble("u_price");
            Double tp=result.getDouble("price");
            String cus=result.getString("customer");
            Date date=result.getDate("date");
            int fid=result.getInt("prodid");
            storesale(id,new SalesDetails(fid,product,category,up,quan,tp,cus,date));

        }




        result.close();
        state.close();





    }





}


