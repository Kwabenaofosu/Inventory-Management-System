package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.DataContainer.Gooddetail;
import com.example.Ofosu8249.connector.DataContainer.collections;
import com.example.Ofosu8249.connector.Tables.productTablem;
import com.example.Ofosu8249.connector.Controller;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.util.Queue;
import java.util.Stack;

public class viewStocks extends JPanel implements ActionListener {


    productTablem model;
    JTable table;
    JButton  stacktab;
    JButton listtab;
    JPanel leftp;
    JLabel STOREITEM;
    JPanel rightp;
    JButton queuetab;
    JTextField ids;
    JComboBox Box;
    JButton searchc;
    JLabel idl;
    JButton refreshtab;
    JButton  popbtn;
    JButton peektbn;

    JButton qremovetbn;
    DefaultComboBoxModel LIS;
    JButton lcounttbn;
    JButton lremovetbn;
    JPanel Stackpanel;
    JPanel QuePanel;
    JPanel ListPanel;
    JPanel DESCRIPT;
        CardLayout ShowCards;
        JPanel Mainpanel;
    GridBagLayout fl=new GridBagLayout();
    JPanel tabs;
    JButton     collectionbtn;
    JButton tablebtn;
    GridBagConstraints sty;
    GridBagConstraints quty;
    GridBagConstraints listy;
    Border newborder;
    private  int itemcount;
    public  int randcolor;
    public  List<Integer>colorcollection;
    public List<Color>colstring;

    Border margin;

    private Controller control;
    collections db=new collections();


    viewStocks(){
        quty=new GridBagConstraints();
        sty=new GridBagConstraints();
        listy=new GridBagConstraints();
        colstring=new ArrayList<>(){};
        colstring.add(Color.BLACK);
        colstring.add(new Color(140, 30, 5));
        colstring.add(Color.GREEN);
        colstring.add(Color.BLUE);
        colstring.add(new Color(201, 4, 155));
collectionbtn=new JButton("View collection");



        model=new productTablem();
        table=new JTable(model);
        Border bd=new EmptyBorder(20,30,50,30);
        table.setBorder(bd);
        JScrollPane spt=new JScrollPane(table);
        spt.setBackground(new Color(205, 224, 219));

        table.setBackground(Color.WHITE);
        spt.setBorder(new CompoundBorder( bd,new borderDesign(20)));
        BorderLayout mainlayout=new BorderLayout();
        ShowCards=new CardLayout();
        GridBagLayout Stacl=new GridBagLayout();
        GridBagLayout Quel=new GridBagLayout();
        GridBagLayout Listl=new GridBagLayout();

        Stackpanel=new JPanel(Stacl);

        QuePanel=new JPanel(Quel);
        ListPanel=new JPanel(Listl);
        DESCRIPT=new JPanel(mainlayout);
        Mainpanel=new JPanel(ShowCards);
        Mainpanel.add(spt,"tables");
        Mainpanel.add(DESCRIPT,"collection");
        Stackpanel.setBackground(new Color(231, 235, 252));
        QuePanel.setBackground(new Color(207, 211, 246));
        ListPanel.setBackground(new Color(222, 225, 232));
tablebtn=new JButton("view Table");
Stackpanel.setBorder(new CompoundBorder(new EmptyBorder(20,20,20,20),new borderDesign(20)));
QuePanel.setBorder(new CompoundBorder(new EmptyBorder(20,20,20,20),new borderDesign(20)));
ListPanel.setBorder(new CompoundBorder(BorderFactory.createTitledBorder("List Container"),new borderDesign(20)));
QuePanel.setPreferredSize(new Dimension(300,200));
Stackpanel.setPreferredSize(new Dimension(300,200));




        DESCRIPT.add(Stackpanel,BorderLayout.WEST);
        DESCRIPT.add(QuePanel,BorderLayout.EAST);
        DESCRIPT.add(ListPanel,BorderLayout.CENTER);



      randcolor= (int) (Math.random()*10);

STOREITEM=new JLabel("Total items= N/A");
STOREITEM.setForeground(Color.RED);
        control=new Controller();
        stacktab=new JButton("Stack");
        queuetab=new JButton("Queue");
        listtab=new JButton("List");
        refreshtab=new JButton("Reload");
        newborder=BorderFactory.createTitledBorder("Actions Controls");
        margin=new EmptyBorder(10,0,10,0);
Box=new JComboBox();
LIS=new DefaultComboBoxModel();
LIS.addElement("Beverages");
        LIS.addElement(" Bread/Bakery");
        LIS.addElement("Canned/Jarred Goods");
        LIS.addElement("Dairy");
        LIS.addElement("Dry/Baking Goods");
        LIS.addElement("Frozen Foods");
        LIS.addElement("Meat");
        LIS.addElement("Produce");
        LIS.addElement("Cleaners");
        LIS.addElement("Paper Goods ");
        LIS.addElement("Personal Care");
     Box.setModel(LIS);
searchc=new JButton("search");

ids=new JTextField();



/***** action perform button **/
        popbtn=new JButton("Pop");
         peektbn=new JButton("Peek");

         qremovetbn=new JButton("Remove Q");


       lcounttbn=new JButton("Count");
        lremovetbn=new JButton("Remove");
BorderLayout tabsl=new BorderLayout();
        tabs=new JPanel(tabsl);
setLayout(new BorderLayout());
GridBagLayout   gd=new GridBagLayout();

        GridBagLayout LEFTG=new GridBagLayout();
leftp=new JPanel(LEFTG);
rightp=new JPanel(new FlowLayout());
tabs.add(leftp,BorderLayout.CENTER);

idl=new JLabel("ID");



        /**                         Layout for Action tabs          ***/
        buttondesign(stacktab);
        buttondesign(queuetab);
        buttondesign(refreshtab);
        buttondesign(listtab);





tabs.setBackground(new Color(201, 235, 240));
leftp.setPreferredSize(new Dimension(450,100));
rightp.setPreferredSize(new Dimension(400,100));
leftp.setBorder(new borderDesign(20));
rightp.setBorder(new borderDesign(20));


refreshtab.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {



    }
});

        GridBagConstraints tg=new GridBagConstraints();
        tg.gridx=0;
        tg.gridy=0;
        tg.anchor=GridBagConstraints.LINE_START;
        leftp.add(refreshtab,tg);
        refreshtab.addActionListener(this);
        tg.gridx=1;
        leftp.add(stacktab,tg);
        tg.gridx=2;

        leftp.add(listtab,tg);
        tg.gridx=3;

        leftp.add(queuetab,tg);
        stacktab.addActionListener(this);
        listtab.addActionListener(this);
        queuetab.addActionListener(this);

        tg.gridx=0;
        tg.gridy=3;

        leftp.add(popbtn,tg);
        tg.gridx=1;
        tg.gridy=3;
        leftp.add(peektbn,tg);
        tg.gridx=0;
        tg.gridy=3;

        leftp.add(qremovetbn,tg);


        tg.gridx=0;
        tg.gridy=3;
        leftp.add(lremovetbn,tg);

        tg.gridx=0;
        tg.gridy=3;
        leftp.add(qremovetbn,tg);
        tg.gridx=1;
        tg.gridy=3;
        leftp.add(STOREITEM,tg);
        tg.gridx=2;
leftp.add(collectionbtn,tg);
leftp.add(tablebtn,tg);

        tg.gridx=4;
        tg.gridy=3;
    leftp.add(searchc,tg);
    tg.gridx=3;
    leftp.add(Box,tg);
    tablebtn.setVisible(false);


        ids.setPreferredSize(new Dimension(50,30));



        popbtn.setVisible(false);
        peektbn.setVisible(false);
        lremovetbn.setVisible(false);
        qremovetbn.setVisible(false);
        idl.setVisible(false);

/******           tab end                                          ***/
        tabs.setPreferredSize(new Dimension(100,200));

tabs.setBorder(new CompoundBorder(newborder,margin));


        add(Mainpanel,BorderLayout.CENTER);
        add(tabs,BorderLayout.PAGE_START);
        /******************************actions for tabs *****************/
qremovetbn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        try {

            control.delectQueue();

            setp(control.getall());
            Queue<Gooddetail> s=control.getqgood();
            STOREITEM.setText("Total Queue items= "+ control.getqgood().size());
          QuePanel.removeAll();
          QuePanel.repaint();


            int yy=4;
            int xx=0;
            quty.gridx=0;
            quty.gridy=0;
            quty.anchor=GridBagConstraints.FIRST_LINE_START;
           QuePanel.add(new JLabel( "My List Container"),quty);




            for(Gooddetail g: s){
                quty.gridy=yy;
                quty.gridx=xx;
               QuePanel.add(new JLabel( "  ID"+":"+g.getId() +" = "+g.getGood()),quty);
                yy++;
                if(yy==15){
                    xx=1;
                }

            }
            refresh();


            control.load();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
            throw new RuntimeException(ex);

        }
    }
});
lremovetbn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        if(ids.getText() !=""){
            int a=Integer.parseInt(ids.getText());

            try {
                control.delectList(a);
                setp(control.getall());
                rightp.removeAll();
                rightp.repaint();
                List<Gooddetail>q=control.getlistg();
                STOREITEM.setText("Total List items= "+ q.size());
                setp(control.getall());
                List<Gooddetail> s=control.getlistg();

                ids.setVisible(true);
                int index=1;
                ListPanel.removeAll();
                ListPanel.repaint();
                int yy=2;
                int xx=0;
                quty.gridx=0;
                quty.gridy=0;
                quty.anchor=GridBagConstraints.FIRST_LINE_START;
                ListPanel.add(new JLabel( "My List Container"),quty);
                quty.gridx=0;
                quty.gridy=2;
                ListPanel.add(idl);
                quty.gridx=1;
                quty.gridy=2;
                ListPanel.add(ids);


                for(Gooddetail g: s){
                    quty.gridy=yy;
                    quty.gridx=xx;
                    ListPanel.add(new JLabel( "  ID"+":"+g.getId() +" = "+g.getGood()),quty);
                    yy++;
                    if(yy==8){
                        xx=1;
                    }

                }
                refresh();
            } catch (Exception ex) {

                throw new RuntimeException(ex);
            }

            setp(control.getall());
            refresh();

        }
        else{
            JOptionPane.showMessageDialog(null,"Enter INDEX TO PERFORM LIST REMOVE");
        }
      ;
    }
});
tablebtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        collectionbtn.setVisible(true);
        tablebtn.setVisible(false);
        ShowCards.show(Mainpanel,"tables");
        searchc.setVisible(true);
        Box.setVisible(true);
    }
});
collectionbtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        ShowCards.show(Mainpanel,"collection");
        collectionbtn.setVisible(false);
        tablebtn.setVisible(true);
        searchc.setVisible(false);
        Box.setVisible(false);


    }
});
searchc.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String cat= Box.getSelectedItem().toString();

        try {
            control.searchcat(cat);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
setp(control.getSgood());
        refresh();

    }
});
popbtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        try {

            control.delectStack();

            control.load();

            setp(control.getall());
            Stack<Gooddetail>s=control.getgood();
            STOREITEM.setText("Total Stack items= "+ s.size());
            setp(control.getall());
            rightp.removeAll();
            rightp.repaint();
            ids.setVisible(true);
            int index=1;
            Stackpanel.removeAll();
            Stackpanel.repaint();
            int yy=18;
            int xx=0;
            quty.gridx=0;
            quty.gridy=0;
            quty.anchor=GridBagConstraints.FIRST_LINE_START;
            Stackpanel.add(new JLabel( "My Stack Container"),quty);


            for(Gooddetail g: s){
                quty.gridy=yy;
                quty.gridx=xx;
               Stackpanel.add(new JLabel( "  ID"+":"+g.getId() +" = "+g.getGood()),quty);
                --yy;
            }

            refresh();

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
});


    }


    /******************** searching***********************************************************************/


    public void setp(List<Gooddetail> p){model.setp(p);
    }
    



    public void refresh(){

        model.fireTableDataChanged();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        var btn=e.getSource();


Controller control=new Controller();
        try {
            control.connect();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        if(btn==listtab){
            ids.setVisible(true);
            idl.setVisible(true);
        }

        if(btn==refreshtab) {

                try {
                    control.load();

                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }


                Box.setVisible(true);
                searchc.setVisible(true);
                setp(control.getall());

               List<Gooddetail> c=control.getall();
            quty.anchor=GridBagConstraints.FIRST_LINE_START;

                STOREITEM.setText("Total items= "+ c.size());

                refresh();

                popbtn.setVisible(false);
                peektbn.setVisible(false);
                lremovetbn.setVisible(false);
                qremovetbn.setVisible(false);

            }
           if(btn==stacktab) {

               try {
                   control.load();
               } catch (SQLException ex) {
                   throw new RuntimeException(ex);
               }

               Stack<Gooddetail>s=control.getgood();
               STOREITEM.setText("Total Stack items= "+ s.size());
               setp(control.getall());
               searchc.setVisible(false);
               Box.setVisible(false);



               Stackpanel.removeAll();
               Stackpanel.repaint();
               int yy=18;
               int xx=0;
               quty.gridx=0;
               quty.gridy=0;
               Stackpanel.add(new JLabel( "My List Container"),quty);
               quty.anchor=GridBagConstraints.FIRST_LINE_START;


               for(Gooddetail g: s){
                   quty.gridy=yy;
                   quty.gridx=xx;
                   Stackpanel.add(new JLabel( "  ID"+":"+g.getId() +" = "+g.getGood()),quty);
                   --yy;
               }

               refresh();



               popbtn.setVisible(true);
               peektbn.setVisible(true);
               lremovetbn.setVisible(false);
               qremovetbn.setVisible(false);
           }
            if(btn==queuetab) {
                try {
                    control.load();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                setp(control.getall());
                Queue<Gooddetail> s=control.getqgood();
                STOREITEM.setText("Total Queue items= "+ control.getqgood().size());
                QuePanel.removeAll();
                QuePanel.repaint();


                int yy=1;
                int xx=0;
                quty.gridx=0;
                quty.gridy=0;
                quty.anchor=GridBagConstraints.FIRST_LINE_START;
                QuePanel.add(new JLabel( "My Queue Container"),quty);


                for(Gooddetail g: s){
                    quty.gridy=yy;
                    quty.gridx=xx;
                    QuePanel.add(new JLabel( "  ID"+":"+g.getId() +" = "+g.getGood() ),quty);
                    yy++;
                    if(yy==16){
                        xx=1;
                        yy=0;
                    }

                }
                refresh();
                popbtn.setVisible(false);
                peektbn.setVisible(false);
                lremovetbn.setVisible(false);
                qremovetbn.setVisible(true);
                searchc.setVisible(false);
                Box.setVisible(false);


            }
            if(btn==listtab) {

                try {
                    control.load();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

                setp(control.getall());

                rightp.repaint();
                List<Gooddetail>q=control.getlistg();
                        STOREITEM.setText("Total List items= "+ q.size());
                setp(control.getall());
                List<Gooddetail> s=control.getlistg();
                quty.anchor=GridBagConstraints.FIRST_LINE_START;
ids.setVisible(true);
idl.setVisible(true);
               ListPanel.removeAll();
                ListPanel.repaint();
                int yy=2;
                int xx=0;
                quty.gridx=0;
                quty.gridy=0;
                ListPanel.add(new JLabel( "My List Container"),quty);
                quty.gridx=0;
                quty.gridy=2;
           ListPanel.add(idl);
                quty.gridx=1;
                quty.gridy=2;
                ListPanel.add(ids);


                for(Gooddetail g: s){
                    quty.gridy=yy;
                    quty.gridx=xx;
                    ListPanel.add(new JLabel( "  ID"+":"+g.getId() +" = "+g.getGood()),quty);
                    yy++;
                    if(yy==18){
                        xx=1;
                        yy=0;
                    }

                }
                refresh();
                popbtn.setVisible(false);

                peektbn.setVisible(false);

                lremovetbn.setVisible(true);

                qremovetbn.setVisible(false);
                searchc.setVisible(false);
                Box.setVisible(false);

            }





    }

    private static class borderDesign implements Border {

        private int radius;


        borderDesign(int radius) {
            this.radius = radius;
        }


        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }


        public boolean isBorderOpaque() {
            return true;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }
    }
    private void buttondesign(JButton b){

        b.setBackground(Color.WHITE);
        b.setPreferredSize(new Dimension(180,60));
       b.setBorder(new borderDesign(20));

        b.setOpaque(false);
       b.setFocusPainted(false);
       b.setBorderPainted(false);

       b.setFont(new Font("Arial", Font.BOLD, 14));
    }
    private void buttonp(JButton b){

        b.setOpaque(false);
        b.setForeground(new Color(1, 2, 3));
        b.setPreferredSize(new Dimension(70,20));
        b.setBorder(new borderDesign(20));
        b.setFocusPainted(false);
        b.setFont(new Font("Arial", Font.BOLD, 14));
    }

}


