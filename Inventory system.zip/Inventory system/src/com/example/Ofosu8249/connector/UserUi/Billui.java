package com.example.Ofosu8249.connector.UserUi;

import javax.swing.*;
import java.awt.*;


public class Billui extends JPanel {


    Billui(){
        setBackground(Color.RED);
    }
}
