package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.DataContainer.collections;
import com.example.Ofosu8249.connector.Controller;
import com.example.Ofosu8249.connector.DataContainer.SalesDetails;
import com.example.Ofosu8249.connector.DataContainer.vendorDetails;


import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.SQLException;

import java.util.Map;

public class viewIStockstUi extends JPanel implements  ActionListener{


    public collections DB;
    public DefaultTableModel model;




    JTable table;






    public JButton addbtn;
    public JTextField search;
    public JButton searchbtn;



    private Controller control;

    private JPanel Toppanel;
    private JPanel centerpanel;

    public viewIStockstUi(){
        collections DB=new collections();

        model=new DefaultTableModel(0,0);
        model.addColumn("SALE_CODE");
        model.addColumn("PRODUCT");
        model.addColumn("CATEGORY");
        model.addColumn("QUANTITY");
        model.addColumn("UNIT_PRICE");
        model.addColumn("TOTAL_PRICE");
        model.addColumn("PRODUCT ID");
        model.addColumn("CUSTOMER");
        model.addColumn("DATE");

        table=new JTable(model);






        control=new Controller();
        GridBagLayout gb=new GridBagLayout();
        GridBagLayout tg=new GridBagLayout();
        Toppanel=new JPanel(new FlowLayout());
        centerpanel=new JPanel(gb);
        BorderLayout bl=new BorderLayout();
        setLayout(bl);
Toppanel.setBackground(new Color(223, 242, 239));
        setBackground(new Color(223, 242, 239));
        BorderLayout tbl=new BorderLayout();


/**   adding Jpanels left and right   ----------------------------------------------------------------   */
        add(Toppanel,BorderLayout.NORTH);
        Toppanel.setPreferredSize(new Dimension(200,100));
        add(centerpanel,BorderLayout.CENTER);
        addbtn=new JButton("ALL MY SALES");
   Toppanel.add(addbtn);
   addbtn.setBorder(new borderDesign(30));
   addbtn.setPreferredSize(new Dimension(200,50));

        addbtn.setOpaque(false);
        addbtn.setFocusPainted(false);
        centerpanel.setBorder(new EmptyBorder(0,30,0,20));


centerpanel.setBackground(new Color(201, 235, 240));
        centerpanel.setBorder(new borderDesign(30));
        setBorder(new EmptyBorder(10, 10, 10, 10));

/**     ALIGNING LABLES IN LEFT PANEL---------------------------------------------------------------------*/






/*** --------------------------------------------------------------------------------------------------------- */






        centerpanel.setLayout(tbl);



/****                *********************                         ***/


        addbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {



                    Controller control=new Controller();
                    try {
                        control.connect();
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }


                    try {
                        DB.connect();
                        DB.Load_data_SALE();
                        model.setRowCount(0);
                        for(Map.Entry<Integer, SalesDetails>ind:DB.getSales().entrySet()){
                            model.addRow(new Object[]{ind.getKey(),ind.getValue().getProduct(),ind.getValue().getCat(),
                                    ind.getValue().getQty(),ind.getValue().getPriceu(),ind.getValue().getTotal(),
                                    ind.getValue().getId(),ind.getValue().getCus(),ind.getValue().getDate()});
                        }

                        System.out.println("vendor saved");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                    for(Map.Entry<String, vendorDetails>indes:DB.Getvendors().entrySet()){

                    }
                }catch (
                        Exception ee
                ){
                    JOptionPane.showMessageDialog(null,ee.getMessage());
                }
            }



        });




        Border bd=new EmptyBorder(50,50,50,50);



        JScrollPane spt=new JScrollPane(table);
        spt.setBorder(bd);
        spt.setBackground(new Color(216, 238, 241));
        centerpanel.add(spt,BorderLayout.CENTER);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.print("ok button working");
    }


    private static class borderDesign implements Border {

        private int radius;


        borderDesign(int radius) {
            this.radius = radius;
        }


        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }


        public boolean isBorderOpaque() {
            return true;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }

    }




}


