package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.DataContainer.Gooddetail;
import com.example.Ofosu8249.connector.DataContainer.collections;
import com.example.Ofosu8249.connector.Controller;
import com.example.Ofosu8249.connector.DataContainer.SalesDetails;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;


public class salesUi extends JPanel {
    public JLabel catl;

    public JLabel prodl;
    public JLabel datl;
    public JLabel quatl;
    public JLabel purchl;
    public  JOptionPane SHOW;
    public JLabel salel;
    public JLabel grossl;
    public JLabel grosSalel;
    public JTextField catname;
    public JTextField productn;
    public JTextField customer;
    public JLabel custname;
    public JTextField quatname;
    public JTextField total;
    public JLabel totall;
    public JTextField purchname;
    public JTextField salename;
    public JTextField grosname;
    public JTextField grosSalename;
    private String ID;
    private String cats;
    private String Produc;
    private String quant;
    private String pric;
    private String totp;
    private double grosp;
    public JButton buy;
    public JButton start;
    public JButton update;
private JPanel controls;
DefaultTableModel model;
private JTable table;
    List<Gooddetail> Products;
    private collections DB=new collections();
    salesUi(){
DB=new collections();
custname=new JLabel("Customer");
customer=new JTextField();


        Controller control=new Controller();


        update=new JButton("Update");
        total=new JTextField(10);
        totall=new JLabel("Gross Price");
        catl=new JLabel("category");
        prodl=new JLabel("Product");
        quatl=new JLabel("Quantity");
        purchl=new JLabel("Price per unit");
        salel=new JLabel("total Price");
        start=new JButton("Resume sales");
        start.setPreferredSize(new Dimension(200,40));

        quatname=new JTextField(10);
        purchname=new JTextField(10);
        salename=new JTextField(10);
        grosname=new JTextField(10);
        grosSalename=new JTextField(10);
        catname=new JTextField(10);
        productn=new JTextField(10);

designfield(quatname);
designfield(purchname);
designfield(salename);
designfield(grosSalename);
designfield(grosname);
designfield(catname);
designfield(productn);

        buy=new JButton("BUY");
        buy.setVisible(false);

        model=new DefaultTableModel(0,0);
        GridBagLayout gbl=new GridBagLayout();


        model.addColumn( "ID");

       model.addColumn("CATEGOORY");
        model.addColumn("PRODUCT");

        model.addColumn("DATE");
        model.addColumn("QUANTITY");
        model.addColumn("PRICE PER UNIT");
        model.addColumn("SALE PRICE");



        controls=new JPanel(gbl);
        table=new JTable(model);

        setBackground(Color.BLUE);
        setLayout(new BorderLayout());
        add(controls,BorderLayout.PAGE_START);
controls.setBackground(new Color(  223, 242, 239));
        JScrollPane spt=new JScrollPane(table);
spt.setBorder(new EmptyBorder(30,20,20,30));
  spt.setBorder(new CompoundBorder(new EmptyBorder(40,40,40,40),new RoundedBorder(20)));
        controls.setPreferredSize(new Dimension(600,200));

        add(spt,BorderLayout.CENTER);
        spt.setBackground(new Color(214, 250, 242));
        GridBagConstraints gc=new GridBagConstraints();

        gc.gridx=0;
        gc.gridy=0;
        gc.anchor=GridBagConstraints.FIRST_LINE_START;
        gc.insets=new Insets(0,0,5,100);
        controls.add(catl,gc);

        gc.gridy=1;
        gc.anchor=GridBagConstraints.FIRST_LINE_START;
        gc.insets=new Insets(0,0,5,100);
        controls.add(catname,gc);


        gc.gridy=2;
        gc.insets=new Insets(0,0,5,0);

        controls.add(prodl,gc);
        gc.gridy=3;
        gc.insets=new Insets(0,0,5,0);
        controls.add(productn,gc);







        gc.gridy=4;

        gc.insets=new Insets(0,0,10,0);

        controls.add(quatl,gc);
        gc.gridy=5;

        gc.insets=new Insets(0,0,0,0);

        controls.add(quatname,gc);


        gc.gridx=1;
        gc.gridy=0;

        gc.insets=new Insets(0,0,10,50);

        controls.add(purchl,gc);
        gc.gridy=1;

        gc.insets=new Insets(0,0,0,50);

        controls.add(purchname,gc);




        /** quantity*/

        gc.gridy=2;
        controls.add(salel,gc);


        gc.gridy=3;
        gc.insets=new Insets(0,0,10,50);

        controls.add(salename,gc);


        gc.gridx=2;
        gc.gridy=0;

        gc.insets=new Insets(0,0,10,0);

        controls.add(start,gc);

        gc.gridx=1;
        gc.gridy=4;
        controls.add(custname,gc);
        gc.gridx=1;
        gc.gridy=5;
        controls.add(customer,gc);
        customer.setColumns(10);
        gc.gridx=2;
        gc.gridy=0;

        controls.add(buy,gc);
        gc.gridx=1;
        gc.gridy=3;

        buy.setPreferredSize(new Dimension(100,40));


/*** purchase*/

        buy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cato=catname.getText();
                String producto=productn.getText();
                int quantt=Integer.parseInt(quatname.getText());
                double u_p=Double.parseDouble(purchname.getText());
                double ttt=Double.parseDouble(salename.getText());
                int qty=Integer.parseInt(quant);
                int selqty=qty-quantt;

                String cust=customer.getText();
                DB.storesale(Integer.parseInt(ID),new SalesDetails(producto,cato,u_p,quantt,ttt,cust));

                try {
                    DB.connect();
                    DB.save_To_vsaleDate();
                    DB.connect();

                    DB.update_vsaleD(selqty,Integer.parseInt(ID));
                    JOptionPane.showMessageDialog(null,selqty+" "+ID);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
            purchname.getDocument().addDocumentListener(new DocumentListener() {
        public void changedUpdate(DocumentEvent e) {

        }
        public void removeUpdate(DocumentEvent e) {

        }
        public void insertUpdate(DocumentEvent e) {
          if(quatname.getText() !=""){
              int a= Integer.parseInt(quatname.getText());
              double  b=Double.parseDouble(purchname.getText());
              double c=a*b;
              salename.setText(String.valueOf(c));



          }
        }
});


        controls.add(salename,gc);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JTable source = (JTable)evt.getSource();
                int row = table.rowAtPoint(evt.getPoint());
                int col = table.columnAtPoint(evt.getPoint());
                String id=source.getModel().getValueAt(row,0)+"";
                String catt=source.getModel().getValueAt(row,1)+"";
                String prod=source.getModel().getValueAt(row,2)+"";
                String quants=source.getModel().getValueAt(row,4)+"";
                String p=source.getModel().getValueAt(row,5)+"";
                totp=source.getModel().getValueAt(row,6)+"";
                if (row >= 0 && col >= 0) {
ID= id;
cats=catt;
Produc=prod;
quant=quants;
pric=p;


catname.setText(catt);
productn.setText(Produc);
quatname.setText(quants);
purchname.setText(totp);



                }
            }
        });
start.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
model.setRowCount(0);
        try {control.connect();
            control.load();
            for (Gooddetail g:
            control.getall()) {
                model.addRow(new Object[] {
        g.getId(),g.getCategory(),g.getGood(),g.getDate(),g.getQuant(),g.getUnit_price(),g.getSaleprice()
                });
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        buy.setVisible(true);
        start.setVisible(false);
    }
});


    }

    public void designfield(JTextField p){
        p.setPreferredSize(new Dimension(300,25));
    }


    private static class RoundedBorder implements Border {

        private int radius;


        RoundedBorder(int radius) {
            this.radius = radius;
        }


        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }


        public boolean isBorderOpaque() {
            return true;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }

    }
}
