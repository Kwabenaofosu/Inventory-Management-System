package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.DataContainer.vendorDetails;
import com.example.Ofosu8249.connector.Tables.productTablem;
import com.example.Ofosu8249.connector.Controller;
import com.example.Ofosu8249.connector.DataContainer.collections;


import javax.swing.*;

import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Map;


public class newStock extends JPanel implements ActionListener {
   public JComboBox combo1;
   public JComboBox combo2;
   public JComboBox combo3;

   public JLabel catl;
   public JLabel prodl;
   public JLabel datl;
   public JLabel quatl;
   public JLabel purchl;
   public JLabel salel;
   public JLabel grossl;
   public JLabel grosSalel;
   public JLabel addnamel;
    public JFormattedTextField datename;
    public JTextField quatname;
    public JTextField purchname;
    public JTextField salename;
    public JTextField grosname;
    public JTextField grosSalename;
    public JButton savebtn;
    public JButton addbtn;
    public JButton removebtn;
    public Color colorsave;
    public JLabel vendorl;
    public JTextField vendorname;
    public collections DB;


    DefaultComboBoxModel bevlist;
    DefaultComboBoxModel vendorlist;
    DefaultComboBoxModel Breadlist;
    DefaultComboBoxModel Cannedlist;
    DefaultComboBoxModel Dairylist;
    DefaultComboBoxModel Drylist;
    DefaultComboBoxModel Frozenlist;
    DefaultComboBoxModel Meatlist;
    DefaultComboBoxModel Producelist;
    DefaultComboBoxModel Cleanerslist;
    DefaultComboBoxModel Paperlist;
    DefaultComboBoxModel Personallist;
    DefaultComboBoxModel ded;
    Font labelf;
    Dimension setdimension;
    Border borderd;
    Border borderfocus;
    frontPage des;


private Controller controller;

private final viewStocks viewGood_p;
    public newStock(viewStocks vg) throws Exception {
        vendorlist=new DefaultComboBoxModel();
        combo3=new JComboBox();

controller=new Controller();

        viewGood_p=vg;
DB=new collections();
        DB.connect();
        DB.Load_data_v();
        for(Map.Entry<String, vendorDetails>ind:DB.Getvendors().entrySet()){
vendorlist.addElement(ind.getKey());

        }
combo3.setModel(vendorlist);

        ClassLoader cl= this.getClass().getClassLoader();
        URL dirr=cl.getResource("UserUi/icons/addq.png");
        ImageIcon icon6=new ImageIcon(dirr);
        Image adds = icon6.getImage().getScaledInstance(20 ,20, Image.SCALE_DEFAULT);
        ImageIcon ad=new ImageIcon(adds);

        URL dirr1=cl.getResource("UserUi/icons/minus.png");
        ImageIcon icon7=new ImageIcon(dirr1);
        Image minuss = icon7.getImage().getScaledInstance(15 ,15, Image.SCALE_DEFAULT);
        ImageIcon mi=new ImageIcon(minuss);

        URL dirr2=cl.getResource("UserUi/icons/save.png");
        ImageIcon icon8=new ImageIcon(dirr2);
        Image savedb = icon8.getImage().getScaledInstance(15 ,15, Image.SCALE_DEFAULT);
        ImageIcon sicon=new ImageIcon(savedb);
        borderd= BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(164, 165, 166));
        borderfocus= BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLUE);


        DateFormat dateFormat = new SimpleDateFormat("YYYY/MM/dd");
        datename= new JFormattedTextField(dateFormat);

        datename.setValue(new Date());


        setdimension=new Dimension(100,30);
        colorsave=new Color( 3, 98, 252);
        labelf=new Font("Times New Roman",Font.BOLD,16);
        setLayout(new GridBagLayout());
        vendorl=new JLabel(" Suppliers");
        vendorl.setFont(labelf);
        vendorl.setForeground(colorsave);
       catl=new JLabel("Category");
       catl.setFont(labelf);
       catl.setForeground(colorsave);
     prodl=new JLabel("Product Name");
        prodl.setFont(labelf);
        prodl.setForeground(colorsave);
     datl=new JLabel("Date");
        datl.setFont(labelf);
        datl.setForeground(colorsave);
       quatl=new JLabel("Quantity");
        quatl.setFont(labelf);
        quatl.setForeground(colorsave);
        purchl=new JLabel("price per unit GH₵");
        purchl.setFont(labelf);
        purchl.setForeground(colorsave);
     salel=new JLabel("Sell Price GH₵");
        salel.setFont(labelf);
        salel.setForeground(colorsave);
         grossl=new JLabel("Gross Price GH₵");
        grossl.setFont(labelf);
        grossl.setForeground(colorsave);
     grosSalel=new JLabel("Gross Sales GH₵");
        grosSalel.setFont(labelf);
        grosSalel.setForeground(colorsave);
      addnamel=new JLabel("Add Good");
        addnamel.setFont(labelf);
        addnamel.setForeground(colorsave);

vendorname=new JTextField(15);
vendorname.setColumns(15);

        datename.setColumns( 15);


        quatname=new JTextField(15);
        purchname=new JTextField(15);


        salename=new JTextField(15);


        grosname=new JTextField(15);


        grosSalename=new JTextField(15);


       savebtn=new JButton("SAVE");
       removebtn=new JButton("   REMOVE GOOD");
       addbtn=new JButton("  ADD GOOD");
       savebtn.setBackground(colorsave);
       removebtn.setBackground(colorsave);
       addbtn.setBackground(colorsave);
       savebtn.setForeground(Color.WHITE);
       removebtn.setForeground(Color.WHITE);
       addbtn.setForeground(Color.BLUE);

       removebtn.setIcon(mi);
       addbtn.setPreferredSize(new Dimension(200,40));
       addbtn.setBorder(new RoundedBorder(30));
        addbtn.setOpaque(false);
        addbtn.setFocusPainted(false);
       removebtn.setPreferredSize(new Dimension(150,40));
       savebtn.setPreferredSize(new Dimension(120,40));
       savebtn.setIcon(sicon);



combo1=new JComboBox();
combo2=new JComboBox();
combo2.setEditable(true);
combo1.setEditable(true);
        Personallist=new DefaultComboBoxModel();
        bevlist=new DefaultComboBoxModel();
        Breadlist=new DefaultComboBoxModel();
        Cannedlist=new DefaultComboBoxModel();
        Dairylist=new DefaultComboBoxModel();
        Drylist=new DefaultComboBoxModel();
        Frozenlist=new DefaultComboBoxModel();
        Meatlist=new DefaultComboBoxModel();
        Producelist=new DefaultComboBoxModel();
        Cleanerslist=new DefaultComboBoxModel();
        Paperlist=new DefaultComboBoxModel();
        ded=new DefaultComboBoxModel();

DefaultComboBoxModel listcat=new DefaultComboBoxModel();
listcat.addElement("Beverages");
listcat.addElement("Bread/Bakery");
listcat.addElement("Canned/Jarred Goods");
listcat.addElement("Dairy");
listcat.addElement("Dry/Baking Goods");
listcat.addElement("Frozen Foods");
listcat.addElement("Meat");
listcat.addElement("Produce");
listcat.addElement("Cleaners");
listcat.addElement("Paper Goods");
listcat.addElement("Personal Care");

        combo1.setModel(listcat);
        combo1.addActionListener(this);
        combo1.setPreferredSize(new Dimension(150,30));
        combo2.setPreferredSize(new Dimension(150,30));

GridBagConstraints gc=new GridBagConstraints();
/**  vendor*/
gc.gridx=0;
gc.gridy=0;
gc.anchor=GridBagConstraints.FIRST_LINE_START;
gc.insets=new Insets(0,0,10,150);
add(vendorl,gc);

gc.gridy=1;
gc.anchor=GridBagConstraints.FIRST_LINE_START;
gc.insets=new Insets(0,0,30,150);
add(combo3,gc);

/** category */
gc.gridy=2;
gc.insets=new Insets(0,0,10,0);

add(catl,gc);

gc.gridy=3;
gc.insets=new Insets(0,0,30,0);
add(combo1,gc);

/** good name */





gc.gridy=4;

gc.insets=new Insets(0,0,10,0);

add(prodl,gc);


gc.gridy=5;

gc.insets=new Insets(0,0,0,0);

add(combo2,gc);



/** date */

        gc.gridx=1;
        gc.gridy=0;

        gc.insets=new Insets(0,0,10,100);

        add(datl,gc);

        /** datename */
        gc.gridy=1;

        gc.insets=new Insets(0,0,0,100);


        add(datename,gc);



        /** quantity*/

        gc.gridy=2;
        add(quatl,gc);




        gc.gridy=3;

        gc.insets=new Insets(0,0,10,100);

        add(quatname,gc);

/*** purchase*/

gc.gridy=4;
        gc.insets=new Insets(0,0,0,100);

        add(purchl,gc);

        gc.gridy=5;

        gc.insets=new Insets(0,0,0,100);

        add(purchname,gc);

        /** sales  price */

        gc.gridy=0;
        gc.gridx=2;

        gc.insets=new Insets(0,0,10,0);

        add(salel,gc);




        gc.gridy=1;

        gc.insets=new Insets(0,0,0,0);
        gc.anchor=GridBagConstraints.FIRST_LINE_START;
        add(salename,gc);


        /**  Gross price */

        gc.gridy=2;

        gc.insets=new Insets(0,0,10,0);
        add(grossl,gc);



        gc.gridy=3;
        gc.insets=new Insets(0,0,0,0);
        add(grosname,gc);

        /** gross sales*/
        gc.gridy=4;
        gc.insets=new Insets(0,0,10,0);
        add(grosSalel,gc);


        gc.gridy=5;
        gc.insets=new Insets(0,0,0,0);
        add(grosSalename,gc);


/** add button */
        gc.gridy=6;
        gc.gridx=0;
        gc.insets=new Insets(50,0,0,0);

        add(addbtn,gc);

/**  save */
        gc.gridx=2;
        gc.gridy=6;
        gc.insets=new Insets(50,0,0,0);
       /** add(savebtn,gc);
*/


        setBackground(new Color(223, 242, 239));



setcolor(quatname);
setcolor(datename);
setcolor(purchname);
setcolor(salename);
setcolor(grosname);
setcolor(grosSalename);





        removebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    controller.delectStack();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        addbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DB.stackGooddetail.clear();
                DB.queueGooddetail.clear();
                DB.listgood.clear();

                productTablem gm=new productTablem();
                collections c=new collections();

             Date dd=new Date(datename.getText());
                java.sql.Date newt= new java.sql.Date(dd.getTime());
                int quatn= Integer.parseInt(quatname.getText().trim());
                double purchn=Integer.parseInt(purchname.getText().trim());
                double salena=Integer.parseInt(salename.getText().trim());
                double  grosna=Integer.parseInt(grosname.getText().trim());
                double grosSalen=Integer.parseInt(grosSalename.getText().trim());
                String vendorn= (String) combo3.getSelectedItem();
                String catsel=(String) combo1.getSelectedItem();
                String productsel=(String) combo2.getSelectedItem();
                try {
                    viewGood_p.refresh();

                    if(DB.cat14.contains(catsel)){
                        controller.addgoodstack(catsel,productsel,newt,quatn,purchn,salena,grosna,grosSalen,catsel,productsel,vendorn);

                        int result = JOptionPane.showConfirmDialog(null, "Click yes to Push product. ", "ADD STOCK GOOD", JOptionPane.YES_NO_OPTION);
                        if (JOptionPane.YES_OPTION == result) {
                            controller.connect();
                            controller.load();
                            controller.save_with_stack();



                        } else if (JOptionPane.NO_OPTION == result) {

                        }else{

                        }


                    }
                    if(DB.cat57.contains(catsel)){

                        controller.addgoodqueue(catsel,productsel,newt,quatn,purchn,salena,grosna,grosSalen,catsel,productsel,vendorn);

                        int result = JOptionPane.showConfirmDialog(null, "Click yes to add product  ", "ADD STOCK GOOD", JOptionPane.YES_NO_OPTION);
                        if (JOptionPane.YES_OPTION == result) {
                            controller.connect();
                            controller.load();
                            controller.save_with_queue();

                        } else if (JOptionPane.NO_OPTION == result) {

                        }else{

                        }



                        viewGood_p.refresh();
                    }
                    if(DB.cat811.contains(catsel)){

                        controller.addgoodlist(catsel,productsel,newt,quatn,purchn,salena,grosna,grosSalen,catsel,productsel,vendorn);

                        int result = JOptionPane.showConfirmDialog(null, "Click yes to add product. ", "ADD STOCK GOOD?", JOptionPane.YES_NO_OPTION);
                        if (JOptionPane.YES_OPTION == result) {
                            controller.connect();
                            controller.load();
                            controller.save_with_list();

                            viewGood_p.refresh();

                        } else if (JOptionPane.NO_OPTION == result) {

                        }else{

                        }


                    }

                } catch (ParseException ex) {
                    throw new RuntimeException(ex);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
                try {

                    if(catsel=="Beverages" || catsel=="Bread/Bakery" || catsel=="Canned/Jarred Goods" || catsel=="Dairy" ){


                        viewGood_p.refresh();
                    }
                    if(catsel=="Dry/Baking Goods" || catsel=="Frozen Foods" || catsel=="Meat"){


                    }
                    if(catsel=="Produce" || catsel=="Cleaners" || catsel=="Paper Goods" || catsel=="Personal Care"){

                    }



                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }






                viewGood_p.setp(controller.getall());





            }
        });
    }

    /**  remove rows*/







    public void actionPerformed(ActionEvent e)  {
        String combo1_t=(String) combo1.getSelectedItem();
/** beverage list */
        bevlist.addElement("coffee/tea");
        bevlist.addElement("juice");
        bevlist.addElement(" soda");
        bevlist.addElement("pepsi");
        bevlist.addElement("Sparkling drink");
        bevlist.addElement("Mocktail");
        bevlist.addElement("Milkshake");
/**   Breadlist*/
        Breadlist.addElement("sandwich loaves");
        Breadlist.addElement("dinner rolls");
        Breadlist.addElement("tortillas");
        Breadlist.addElement("bagels");
        Breadlist.addElement(" banana bread");
        Breadlist.addElement("corn bread");
        Breadlist.addElement("irish soda bread");
        Breadlist.addElement("rye bread");
      /**   Canned/Jarred Goods*/
        Cannedlist.addElement("coconut milk");
        Cannedlist.addElement("spaghetti sauce");
        Cannedlist.addElement("ketchup");
        Cannedlist.addElement("baby corn");
        Cannedlist.addElement("olives");
        Cannedlist.addElement("diced green chiles");
        Cannedlist.addElement("pumpkin");
        Cannedlist.addElement("jackfruit");
    /** Dairy */
        Dairylist.addElement("cheeses");
        Dairylist.addElement("eggs");
        Dairylist.addElement("milk");
        Dairylist.addElement("yoghurt");
        Dairylist.addElement("butter");
        Dairylist.addElement("sour cream");
        Dairylist.addElement("Ice Cream");
        Dairylist.addElement("heavy cream");


    /**  Dry/Baking Goods*/
        Drylist.addElement("pasta");
        Drylist.addElement("sugar");
        Drylist.addElement("flour");
        Drylist.addElement("cereals");
        Drylist.addElement("salt");
        Drylist.addElement("fats");
        Drylist.addElement("leaveners");
        Drylist.addElement("baking Soda");

        /**     Frozen Foods*/


        Frozenlist.addElement(" waffles,");
        Frozenlist.addElement("ice cream");
        Frozenlist.addElement("vegetables");
        Frozenlist.addElement("ice cream");
        Frozenlist.addElement("plain chicken");
        Frozenlist.addElement("sausages");
        Frozenlist.addElement("pizza");
        Frozenlist.addElement("frozen bananas");
        Frozenlist.addElement("soy beans");


        /**   Meat list */



        Meatlist.addElement(" lunch meat");
        Meatlist.addElement("turkey");
        Meatlist.addElement("beef");
        Meatlist.addElement("pork");
        Meatlist.addElement("chicken");
        Meatlist.addElement("prawns");
        Meatlist.addElement("crab");
        Meatlist.addElement("lobster");

        /**  Produce – */
        Producelist.addElement("strawberries");
        Producelist.addElement("vegetables");
        Producelist.addElement("spinach");
        Producelist.addElement("nectarines");
        Producelist.addElement("apples");
        Producelist.addElement("grapes");
        Producelist.addElement("hot Peppers");
        Producelist.addElement("cherries");

        /**   Cleaners */
        Cleanerslist.addElement("laundry detergent");
        Cleanerslist.addElement("dishwashing liquid");
        Cleanerslist.addElement("all-purpose cleaner");
        Cleanerslist.addElement("oven cleaner");
        Cleanerslist.addElement("baking soda");
        Cleanerslist.addElement("white vinegar");
        Cleanerslist.addElement("scrubbing sponges");


        /**  Paper Goods*/

        Paperlist.addElement("paper towels");
        Paperlist.addElement("toilet paper");
        Paperlist.addElement("aluminium foil");
        Paperlist.addElement("sandwich bags");
        Paperlist.addElement("paper Packs");
        Paperlist.addElement("linerboard");
        Paperlist.addElement("paperboard");


        /**  Personal Care*/

        Personallist.addElement("shampoo");
        Personallist.addElement("soap");
        Personallist.addElement("hand soap");
        Personallist.addElement("shaving cream");
        Personallist.addElement("hair clippers");
        Personallist.addElement("cotton pads");
        Personallist.addElement("shaving cream");
        Personallist.addElement("baby powder");
        Personallist.addElement("perfumes");

        ded.addElement("enter the name of good");

/** switch controller */
switch(combo1_t){
    case "Beverages":
        combo2.setModel(bevlist);
        addbtn.setText("STACK Push");
        break;
    case "Bread/Bakery":
        combo2.setModel(Breadlist);
        addbtn.setText("STACK Push");
        break;
    case "Canned/Jarred Goods":
        combo2.setModel(Cannedlist);
        addbtn.setText("STACK Push");
        break;
    case "Dairy":
        combo2.setModel(Dairylist);
        addbtn.setText("STACK Push");
        break;
    case "Dry/Baking Goods":
        combo2.setModel(Drylist);
        addbtn.setText("QUEUE ADD");
        break;
    case "Frozen Foods":
        combo2.setModel(Frozenlist);
        addbtn.setText("QUEUE ADD");
        break;
    case "Meat":
        combo2.setModel(Meatlist);
        addbtn.setText("QUEUE ADD");
        break;
    case "Produce":
        combo2.setModel(Producelist);
        addbtn.setText("ADD TO LIST");
        break;
    case "Cleaners":
        combo2.setModel(Cleanerslist);
        addbtn.setText("ADD TO LIST");
        break;
    case "Paper Goods":
        combo2.setModel(Paperlist);
        addbtn.setText("ADD TO LIST");
        break;
    case "Personal Care":
        combo2.setModel(Personallist);
        combo2.setModel(Personallist);

        break;

    default:
        combo2.setModel(ded);
        break;

}





    }

    private void setcolor(JTextField p){
        p.setBackground(Color.WHITE);
        p.setPreferredSize(new Dimension(500,40));


    }
    private static class RoundedBorder implements Border {

        private int radius;


        RoundedBorder(int radius) {
            this.radius = radius;
        }


        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }


        public boolean isBorderOpaque() {
            return true;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }

    }
}
