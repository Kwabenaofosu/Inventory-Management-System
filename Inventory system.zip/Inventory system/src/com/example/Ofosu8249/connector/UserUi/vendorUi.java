package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.Controller;
import com.example.Ofosu8249.connector.DataContainer.collections;
import com.example.Ofosu8249.connector.DataContainer.vendorDetails;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.SQLException;
import java.util.Map;

public class vendorUi extends JPanel implements  ActionListener{

    public JLabel venl;
    public collections DB;
public DefaultTableModel model;
    public JLabel venaddl;
    public JLabel vencontl;
    public JOptionPane showoption;
    public JLabel vencoml;
    public JTextField vendor;
    public JTextField venadd;
    public JLabel productl;
    public JTextField product;
    public JTextField vencont;

    public JTextField vencom;
    public JPanel display;

    JTable table;

public JLabel logo;
    public JLabel cityla;
    public JTextField City;


    public JButton addbtn;
    public JTextField search;
    public JButton Updatebtn;
    public JLabel headerl;



    private Controller control;

    private JPanel lpanel;
    private JPanel rpanel;

    public vendorUi(){
        headerl=new JLabel("Supplier Panel");

collections DB=new collections();

        model=new DefaultTableModel(0,0);
        model.addColumn("ID");
        model.addColumn("NAME");
        model.addColumn("ADDRESS");
        model.addColumn("CONTACT");
        model.addColumn("COMPANY");
        model.addColumn("COUNTRY");
        model.addColumn("CITY");
        table=new JTable(model);




        ClassLoader cl= this.getClass().getClassLoader();
        URL dirr=cl.getResource("UserUi/icons/addq.png");
        ImageIcon icon6=new ImageIcon(dirr);
        Image adds = icon6.getImage().getScaledInstance(20 ,20, Image.SCALE_DEFAULT);
        ImageIcon addicon=new ImageIcon(adds);

logo=new JLabel();


addbtn=new JButton("Add");
search=new JTextField();
search.setColumns(10);

cityla=new JLabel("city");
City=new JTextField();
product=new JTextField();
productl=new JLabel("Country");



Updatebtn =new JButton("Update Table");
        venadd=new JTextField();
        venaddl=new JLabel("Address");
        vendor=new JTextField();
        venl=new JLabel("Vendor Name");
        vencoml=new JLabel("Companys name");
        vencom=new JTextField();
        vencont=new JTextField();
        vencontl=new JLabel("Contact");
        productl.setForeground(new Color(52, 94, 235));

        cityla.setForeground(new Color(67, 108, 248));

        venaddl.setForeground(new Color(52, 94, 235));

        vencoml.setForeground(new Color(52, 94, 235));

        vencontl.setForeground(new Color(52, 94, 235));
        venl.setForeground(new Color(52, 94, 235));

control=new Controller();
GridBagLayout gb=new GridBagLayout();
GridBagLayout tg=new GridBagLayout();
rpanel=new JPanel(tg);
lpanel=new JPanel(gb);
BorderLayout bl=new BorderLayout();
setLayout(bl);

setBackground(new Color(240, 245, 245));
BorderLayout tbl=new BorderLayout();


/**   adding Jpanels left and right   ----------------------------------------------------------------   */
add(lpanel,BorderLayout.NORTH);
lpanel.setPreferredSize(new Dimension(300,250));
add(rpanel,BorderLayout.CENTER);
lpanel.setBackground(new Color(240, 245, 245));
rpanel.setBackground(new Color(240, 245, 245));
rpanel.setPreferredSize(new Dimension(880,500));
lpanel.setBorder(new EmptyBorder(0,0,0,-30));
rpanel.setBorder(new EmptyBorder(0,30,0,20));



rpanel.setBorder(new CompoundBorder(new EmptyBorder(20,0,10,0),new RoundedBorder(30)));
setBorder(new EmptyBorder(10, 10, 10, 10));

/**     ALIGNING LABLES IN LEFT PANEL---------------------------------------------------------------------*/



GridBagConstraints gg=new GridBagConstraints();
gg.anchor=GridBagConstraints.FIRST_LINE_START;
gg.gridy=0;
gg.gridx=0;
gg.weightx=0;
gg.weighty=0;


gg.insets=new Insets(10,0,0,60);

lpanel.add(headerl,gg);
        gg.gridy=1;
        gg.gridx=0;

        lpanel.add(venl,gg);

        gg.gridy=2;
        gg.gridx=0;
        lpanel.add(vendor,gg);
        gg.gridy=3;
        gg.gridx=0;


        lpanel.add(venaddl,gg);
        gg.gridy=4;
        gg.gridx=0;
        lpanel.add(venadd,gg);

        gg.gridy=1;
        gg.gridx=2;
        lpanel.add(vencontl,gg);
        gg.gridy=2;
        gg.gridx=2;
        lpanel.add(vencont,gg);
        gg.gridy=3;
        gg.gridx=2;
       lpanel.add(vencoml,gg);
        gg.gridy=4;
        gg.gridx=2;

        lpanel.add(vencom,gg);
        gg.gridy=1;
        gg.gridx=4;
        lpanel.add(productl,gg);

        gg.gridy=2;
        gg.gridx=4;
        lpanel.add(product,gg);

        gg.gridy=3;
        gg.gridx=4;
        lpanel.add(cityla,gg);
        gg.gridy=4;
        gg.gridx=4;
        lpanel.add(City,gg);
        gg.gridy=5;
        gg.gridx=0;
        lpanel.add(addbtn,gg);
        lpanel.add(Updatebtn,gg);
        lpanel.setBackground(new Color(204, 230, 243));
        lpanel.setBorder(new EmptyBorder(20,0,0,0));

        addbtn.setIcon(addicon);
        addbtn.setVisible(false);




   /**     lpanel.add(search,gbl);
        gbl.gridx=6;
        gbl.gridy=0;
        lpanel.add(Updatebtn,gbl);*/
designtext(vencont);
designtext(vencom);
designtext(venadd);
designtext(vendor);
designtext(product);
designtext(City);
addbtn.setBorder(new RoundedBorder(10));
Updatebtn.setBorder(new RoundedBorder(10));
/*** --------------------------------------------------------------------------------------------------------- */





rpanel.setOpaque(false);
search.setColumns(20);
        search.setPreferredSize(new Dimension(400,40));

lpanel.setForeground(new Color(170, 169, 176));
        rpanel.setForeground(new Color(170, 169, 176));


rpanel.setLayout(tbl);



/****                *********************                         ***/

Updatebtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e){
        try {
            model.setRowCount(0);
            DB.connect();
            DB.Load_data_v();
            System.out.println(DB.Getvendors().size());
            for(Map.Entry<String, vendorDetails>ind:DB.Getvendors().entrySet()){
                model.addRow(new Object[]{ind.getValue().getId(),ind.getKey(),
                        ind.getValue().getAddress(),ind.getValue().getContact(),ind.getValue().getCompany(),

                        ind.getValue().getCountry(),ind.getValue().getTown()});

            }


    Updatebtn.setVisible(false);
    addbtn.setVisible(true);

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
});
addbtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String name;
        String address;
        int contact;
        String company;
        String country;
        String city;
        try {

            name=vendor.getText().trim();
            address=venadd.getText().trim();
          contact=Integer.parseInt(vencont.getText());

           company=vencom.getText().trim();
            country=product.getText().trim();
            city=City.getText();


Controller control=new Controller();
        try {
            control.connect();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

        DB.Addvendor(name,new vendorDetails(address,company,contact,country,city));
        try {
            DB.connect();
            DB.save_To_database_vendor();
            DB.connect();
            DB.Load_data_v();
            model.setRowCount(0);
            for(Map.Entry<String, vendorDetails>ind:DB.Getvendors().entrySet()){
                model.addRow(new Object[]{ind.getValue().getId(),ind.getKey(),
                        ind.getValue().getAddress(),ind.getValue().getContact(),ind.getValue().getCompany(),
                        ind.getValue().getCountry(),ind.getValue().getTown()});
            }


        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        for(Map.Entry<String, vendorDetails>indes:DB.Getvendors().entrySet()){
            System.out.println(indes.getKey().trim()+ " "+indes.getValue().getContact());
        }
        }catch (
                Exception ee
        ){
            JOptionPane.showMessageDialog(null,"Please fill in the required fields ");
        }
    }



});
/***  RIGHT PANEL DESIGN TABLE  **/



        Border bd=new EmptyBorder(20,20,20,20);



        JScrollPane spt=new JScrollPane(table);
        spt.setBorder(bd);
        rpanel.add(spt,BorderLayout.CENTER);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.print("ok button working");
    }

public void designtext(JTextField P){
    P.setPreferredSize(new Dimension(130,30));



P.setBackground(new Color(240, 245, 245));
}
    private static class RoundedBorder implements Border {

        private int radius;


        RoundedBorder(int radius) {
            this.radius = radius;
        }


        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }


        public boolean isBorderOpaque() {
            return true;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }

    }



}


