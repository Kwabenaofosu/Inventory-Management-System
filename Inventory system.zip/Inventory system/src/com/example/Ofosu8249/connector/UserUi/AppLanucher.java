package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.DataContainer.collections;


import javax.swing.*;

public class AppLanucher {

    public static void main(String[] args) throws Exception {


        collections DB=new collections();
        DB.connect();
        DB.Load_data_v();
        vendorUi ven=new vendorUi();




        frontPage mii=new frontPage();

        mii.setSize(1200,650);
        mii.setVisible(true);
        mii.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    }

}

