package com.example.Ofosu8249.connector.UserUi;

import com.example.Ofosu8249.connector.Controller;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;
import java.sql.SQLException;

public class frontPage extends JFrame implements MouseListener {
    CardLayout card;
    JPanel pan;
    JPanel pan1;
    JPanel pan2;
    JPanel pan3;
    JPanel pan4;
    JPanel pan5;
    JPanel pan6;
    JPanel pan7;
    Color  lightBlue;
    viewStocks viewg;

    JButton b1;
    JButton b2;
    JButton b3;
    JButton b4;
    JButton b5;
    JButton b6;

    Border borderl;
    Border margin;
    private  Controller controller;
    frontPage() throws Exception {

        super("NEWBEST StOCK MANAGEMENT");



        /**    IMPORT PAGES */
        vendorUi vendorp=new vendorUi();
GridBagLayout newlayout=new GridBagLayout();
        pan=new JPanel(newlayout);
        viewg=new viewStocks();
        newStock addgood=new newStock(viewg);
        Billui viewb=new Billui();
        salesUi issueg=new salesUi();
        viewIStockstUi viewissueg=new viewIStockstUi();
      controller=new Controller();
        ClassLoader cl= this.getClass().getClassLoader();
        URL dir=cl.getResource("UserUi/icons/shop.png");
        URL dir1=cl.getResource("UserUi/icons/addqs.jpg");
        URL dir2=cl.getResource("UserUi/icons/listqs.jpg");
        URL dir3=cl.getResource("UserUi/icons/statis.png");
        URL dir4=cl.getResource("UserUi/icons/Seek.png");
        URL dir5=cl.getResource("UserUi/icons/statist.png");
        ImageIcon icon1=new ImageIcon(dir);
        ImageIcon icon2=new ImageIcon(dir1);
        ImageIcon icon3=new ImageIcon(dir2);
        ImageIcon icon4=new ImageIcon(dir3);
        ImageIcon icon5=new ImageIcon(dir4);
        ImageIcon icon6=new ImageIcon(dir5);

        Image img1 = icon1.getImage().getScaledInstance(30 ,30, Image.SCALE_DEFAULT);
        Image img2 = icon2.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        Image img3 = icon3.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        Image img4 = icon4.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        Image img5 = icon5.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        Image img6 = icon6.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);

        ImageIcon image1=new ImageIcon(img1);
        ImageIcon image2=new ImageIcon(img2);
        ImageIcon image3=new ImageIcon(img3);
        ImageIcon image4=new ImageIcon(img4);
        ImageIcon image5=new ImageIcon(img5);
        ImageIcon image6=new ImageIcon(img6);



        pan2 =new JPanel();

        card =new CardLayout();
        pan1 =new JPanel(card);

        /** label tabs*/



        b1=new  JButton("     Suppliers");

        b2=new  JButton("     ADD TO STOCK");
        b3=new  JButton("     VIEW GOOD");
b4=new JButton("            VIEW BILL");
        b5=new  JButton("   ISSUE GOOD");
        b6=new  JButton("   VIEW SALES");
        borderl=BorderFactory.createMatteBorder(1,1,1,1,Color.BLUE);
        margin = new EmptyBorder(10,10,10,10);
        b1.addMouseListener(this);
        b2.addMouseListener(this);
        b3.addMouseListener(this);
        b4.addMouseListener(this);
        b5.addMouseListener(this);
        b6.addMouseListener(this);

        b1.setForeground(Color.WHITE);
        b1.setBorder( new CompoundBorder(borderl,margin));
        b2.setForeground(Color.WHITE);
        b3.setForeground(Color.WHITE);
        b4.setForeground(Color.WHITE);
        b5.setForeground(Color.WHITE);
        b6.setForeground(Color.WHITE);
        setLayout(new BorderLayout());




        pan.setBackground(new Color(208, 229, 239));
        pan1.setBackground(new Color(208, 198, 247));


        add(pan,BorderLayout.WEST);
        pan1.add(vendorp,"pan2");
        pan1.add(addgood,"pan3");
        pan1.add(viewg,"pan4");
        pan1.add(viewb,"pan5");
        pan1.add(issueg,"pan6");
        pan1.add(viewissueg,"pan7");




pan.setPreferredSize(new Dimension(300,800));

        add(pan1,BorderLayout.CENTER);

        btndesign(b1);
        btndesign(b2);
        btndesign(b3);
        btndesign(b4);
        btndesign(b5);
        btndesign(b6);



        GridBagConstraints gl=new GridBagConstraints();
        gl.anchor=GridBagConstraints.EAST;
        gl.gridy=0;
        gl.gridx=0;

        pan.add(b1,gl);

        b1.setBorder( borderl);
        gl.gridy=6;

        pan.add(b2,gl);

        gl.gridy=12;

     pan.add(b3,gl);

        gl.gridy=7;
     /**   pan.add(b4,gl);
    b4.setIcon(image4);**/
        gl.gridy=9;
        pan.add(b5,gl);

        gl.gridy=11;
        pan.add(b6,gl);




    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {



        viewg.refresh();
        if(e.getSource()==b1){
            b1.setBorder(borderl);
            b2.setBorder(margin);
            b3.setBorder(margin);
            b4.setBorder(margin);
            b5.setBorder(margin);
            b6.setBorder(margin);
            card.show(pan1,"pan2");




        }

        else if(e.getSource()==b2){
            b2.setBorder(borderl);
            b1.setBorder(margin);
            b3.setBorder(margin);
            b4.setBorder(margin);
            b5.setBorder(margin);
            b6.setBorder(margin);
            card.show(pan1,"pan3");

        }
        else if(e.getSource()==b3){
            b3.setBorder(new CompoundBorder(borderl,margin));
            try {
                controller.connect();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }

            try {

                controller.load();

                    viewg.setp(controller.getall());

                viewg.refresh();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }



            b2.setBorder(margin);
            b1.setBorder(margin);
            b4.setBorder(margin);
            b5.setBorder(margin);
            b6.setBorder(margin);
            card.show(pan1,"pan4");
        }
        else if(e.getSource()==b4){
            b4.setBorder(borderl);
            b2.setBorder(margin);
            b3.setBorder(margin);
            b1.setBorder(margin);
            b5.setBorder(margin);
            b6.setBorder(margin);
            card.show(pan1,"pan5");
        }
        else if(e.getSource()==b5){
            try {
                controller.connect();
                controller.load();

            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }


            b5.setBorder(borderl);
            b2.setBorder(margin);
            b3.setBorder(margin);
            b4.setBorder(margin);
            b1.setBorder(margin);
            b6.setBorder(margin);
            card.show(pan1,"pan6");
        }
        else if(e.getSource()==b6){
            b6.setBorder(borderl);

            b2.setBorder(margin);
            b3.setBorder(margin);
            b4.setBorder(margin);
            b5.setBorder(margin);
            b1.setBorder(margin);
            card.show(pan1,"pan7");

        }








    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    public void actions(){

        viewg.setBackground(Color.RED);
    }

    private static class customBorder implements Border {

        private int radius;


        customBorder(int radius) {
            this.radius = radius;
        }


        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }


        public boolean isBorderOpaque() {
            return true;
        }


        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }
    }
    private void btndesign(JButton b){

        b.setBackground(Color.WHITE);
        b.setPreferredSize(new Dimension(300,60));
       b.setBorder(BorderFactory.createMatteBorder(0,0,0,0,Color.BLUE));



        b.setOpaque(false);
        b.setFocusPainted(false);


b.setForeground(new Color(5, 5, 237));
        b.setFont(new Font("Arial", Font.BOLD, 14));
    }

}
