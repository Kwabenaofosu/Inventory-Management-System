package com.example.Ofosu8249.connector.Tables;

import com.example.Ofosu8249.connector.DataContainer.Gooddetail;
import com.example.Ofosu8249.connector.DataContainer.collections;
import com.example.Ofosu8249.connector.Controller;

import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Stack;

public class productTablem extends AbstractTableModel {


        Stack<Gooddetail>product;
        collections DB=new collections();
        Controller C=new Controller();
        List<Gooddetail> allp;

        String type="ALL";


private String [] col={ "ID","VENDOR","CATEGOORY","PRODUCT",
        "DATE","QUANTITY","PURCHASE PER UNIT","SALE PRICE","GROSS PRICE"};
    @Override
    public String getColumnName(int column) {
        return col[column];
    }

    private static  int c=0;


    @Override
    public int getRowCount() {

        return c;
    }

    @Override
    public int getColumnCount() {
        return 9;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {

    Gooddetail g=allp.get(rowIndex);



        switch(columnIndex){
            case 0:
                return g.getId();
            case 1:
                return g.getVendor();
            case 2:
                return g.getCategory();
            case 3:
                return g.getGood();
            case 4:
                return dateform(g.getDate());
            case 5:
                return g.getQuant();
            case 6:
                return g.getUnit_price();
            case 7:
                return g.getSaleprice();
            case 8:
                return g.getGrossprice();



        }
        return null;
    }

    public void setp(List<Gooddetail> product){
        this.allp=product;
        System.out.println("all count"+allp.size());
        c=this.allp.size();



    }




    public  String dateform(Date e){
        String ee=new SimpleDateFormat("YYYY/MM/dd").format(e);
        return ee;



    }


}
